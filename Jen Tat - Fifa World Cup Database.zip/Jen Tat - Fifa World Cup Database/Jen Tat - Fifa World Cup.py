'''
Created January, 2020
For ICS3U1

@author: Jen Tat
'''
from tkinter import *
import random
import csv
from PIL import Image, ImageTk, ImageSequence

def getPlayer(filename):

    newList = []
    inTop20List = []
    countriesList = []
    clubsList = []
    overallList = []
   
    fileIn = open(filename, encoding='iso8859_2', errors="replace")
    fileIn.readline()
    reader = csv.reader(fileIn)

    for line in reader:

        countriesList.append(line[2].strip())
        clubsList.append(line[4].strip())
        overallList.append(line[3].strip())
        newList.append(line)
        if "Yes" in line[0 : 7]:
            inTop20List.append(line)

    fileIn.close()

    return newList, inTop20List, countriesList, clubsList, overallList

##def getSongArtist(filename):
##
##    newList = []
##    
##    fileIn = open(filename)
##    fileIn.readline()
##    fileIn.readline()
##    reader = csv.reader(fileIn)
##
##    for line in reader:
##        song = []
##        song.append(line[1])
##        song.append(line[2])
##
##        newList.append(song)
##
##    fileIn.close()
##
##    return newList

def setCurrentSelection(event):
    global finalList, currentFilterList
   
    currentIndex = playersListbox.curselection()[0]

    currentSelectionPlayerVar.set(f"Name Of Player: {finalList[currentIndex][0]}")
    currentSelectionClubVar.set(f"Club Name: {finalList[currentIndex][4]}")      

def findRandomPlayers():
    global allPlayers, finalList, currentFilterList

    filteredList = []

    for i in range(0, 12):
        s = random.choice(allPlayers)
        finalList.append(s)
       
    updatePlayerListBox(finalList)
    currentSelectionClubVar.set(f"Club Name: {finalList[0][4]}")
    currentSelectionPlayerVar.set(f"Name Of Player: {finalList[0][0]}")

def alphabetizePlayers():
    global allPlayers, finalList, currentFilterList

##    currentFilterList = []
##    
##    for y in allPlayers:
##        currentFilterList.append(y)
       
    finalList.sort()

    updatePlayerListBox(finalList)
    currentSelectionClubVar.set(f"Club Name: {finalList[0][4]}")
    currentSelectionPlayerVar.set(f"Name Of Player: {finalList[0][0]}")

def changeAge(self):
    ageAmount = ageScaleVar.get()
    return ageAmount
   
def changeWage(Self):
    wageAmount = wageScaleVar.get()
    return wageAmount

def defenceControl():
    filterResults()

def forwardControl():
    filterResults()

def useAgeControl(self):
    filterResults()

def useWageControl(self):
    filterResults()

def handleTop20():
    allList = []
    for player in allPlayers:
        allList.insert(0, player)

    yesList = []
    for play in allPlayers:
        if play[6] == "Yes":
            yesList.insert(0, play)

    noList = []
    for yer in allPlayers:
        if yer[6] == "No":
            noList.insert(0, yer)        
   
    if top20Var.get() == "All":
        listToUse = allList
    elif top20Var.get() == "Yes":
        listToUse = yesList
    elif top20Var.get() == "No":
        listToUse = noList
    return listToUse

def handlePositions(dataList):

    defenceList = []
    for listT in dataList:
        if listT[9] == "Defence":
            defenceList.append(listT)
           
    if defenceCheckVar.get() == 0:
        for cfl in allPlayers:
            if cfl in dataList:
                if cfl[9] == "Defence":
                    dataList.remove(cfl)
    else:
        for urr in dataList:
            if urr[9] == "Defence":
                dataList.remove(urr)

        for ap in defenceList:
            dataList.insert(0, ap)

    forwardList = []
    for stto in dataList:
        if stto[9] == "Forward":
            forwardList.append(stto)
           
    if forwardCheckVar.get() == 0:
        for fcv in allPlayers:
            if fcv in dataList:
                if fcv[9] == "Forward":
                    dataList.remove(fcv)
    else:
        for touse in dataList:
            if touse[9] == "Forward":
                dataList.remove(touse)

        for fw in forwardList:
            dataList.insert(0, fw)
               
    goalkeeperList = []
    for ist in dataList:
        if ist[9] == "GoalKeeper":
            goalkeeperList.append(ist)
           
    if goalkeeperCheckVar.get() == 0:
        for gkcv in allPlayers:
            if gkcv in dataList:
                if gkcv[9] == "GoalKeeper":
                    dataList.remove(gkcv)
    else:
        for tou in dataList:
            if tou[9] == "GoalKeeper":
                dataList.remove(tou)

        for gk in goalkeeperList:
            dataList.insert(0, gk)

    midfieldList = []
    for mfl in dataList:
        if mfl[9] == "MidField":
            midfieldList.append(mfl)
           
    if midfieldCheckVar.get() == 0:
        for mcv in allPlayers:
            if mcv in dataList:
                if mcv[9] == "MidField":
                    dataList.remove(mcv)
    else:
        for ios in dataList:
            if ios[9] == "MidField":
                dataList.remove(ios)

        for mid in midfieldList:
            dataList.insert(0, mid)
    return dataList

def handleFoot(currentList):
    eitherList = []
    for el in currentList:
        eitherList.append(el)
       
    leftList = []
    for ll in currentList:
        if ll[8] == "Left":
            leftList.append(ll)

    rightList = []
    for rl in currentList:
        if rl[8] == "Right":
            rightList.append(rl)
           
    if preferredFootVar.get() == "Left":
        return leftList
    elif preferredFootVar.get() == "Right":
        return rightList
    elif preferredFootVar.get() == "Either":
        return eitherList

def handleCountry(infoList):

    ofThatCountryList = []
    if countriesOptionVar.get() == "All":
        ofThatCountryList = infoList
    else:
        for info in infoList:
            if info[2] == countriesOptionVar.get():
                ofThatCountryList.append(info)

    return ofThatCountryList

def handleInitial(useThisList):

    sameInitialList = []
    userLetter = firstInitVar.get()
    if useInitVar.get() == "Yes":
        if userLetter.isalpha() == True:
            for usl in useThisList:
                if usl[0][0][0] == userLetter.upper():
                    sameInitialList.append(usl)
        else:
           typeInitVar.set("Please try again!")
    elif useInitVar.get() == "No":
        sameInitialList = useThisList
 
    return sameInitialList

def handleAge(takeThisList):
    
    filteredList = []
    ageList = []
    ageYears = changeAge(ageScale)
    for allyers in allPlayers:
        if int(allyers[1]) == ageYears:
            ageList.append(allyers)

    if useAgeVar.get() == 1:
        useAgeScale.config(label="Yes")
        for item in takeThisList:
            if item in ageList:
                filteredList.append(item)
    else:
        useAgeScale.config(label="No")
        filteredList = takeThisList

    return filteredList

def handleWage(takeList):
    
    filteredWageOutList = []
    wageList = []
    wageDollars = changeWage(wageScale)
    for moneyMaker in allPlayers:
        if int(moneyMaker[7]) == wageDollars:
            wageList.append(moneyMaker)

    if useWageVar.get() == 1:
        useWageScale.config(label="Yes")
        for part in takeList:
            if part in wageList:
                filteredWageOutList.append(part)
    else:
        useWageScale.config(label="No")
        filteredWageOutList = takeList

    return filteredWageOutList

##def handleQuantities(takeThisList):
##
##    filteredList = []
##    ageList = []
##    ageYears = changeAge(ageScale)
##    for allyers in allPlayers:
##        if int(allyers[1]) == ageYears:
##            ageList.append(allyers)
##
##    wageList = []
##    wageMoney = changeWage(wageScale)
##    for cit in allPlayers:
##        if int(cit[7]) == wageMoney:
##            wageList.append(cit)
##
##    if useAgeVar.get() == 1:
##        useAgeScale.config(label="Yes")
##        for item in takeThisList:
##            if item in ageList and item in wageList:
##                filteredList.append(item)
##    else:
##        useAgeScale.config(label="No")
##        for item in takeThisList:
##            if item in wageList:
##                filteredList.append(item)
##
##    return filteredList

def handleDuplicates(lastList):
    for ilter in lastList:
        if lastList.count(ilter) > 1:
            lastList.remove(ilter)
            
    return lastList

def handleClubs(listForUse):
    
    ofThatClubList = []
    if clubsOptionVar.get() == "All":
        ofThatClubList = listForUse
    else:
        for forUse in listForUse:
            if forUse[4] == clubsOptionVar.get():
                ofThatClubList.append(forUse)

    return ofThatClubList

def handleOverall(listForScores):
    
    scoreList = []
    if overallVar.get() == "All":
        scoreList = listForScores
    elif overallVar.get() == "40 - 50":
        for lifs in listForScores:
            if int(lifs[3]) >= 40 and int(lifs[3]) <= 50:
                scoreList.append(lifs)
    elif overallVar.get() == "51 - 60":
        for lfs in listForScores:
            if int(lfs[3]) >= 51 and int(lfs[3]) <= 60:
                scoreList.append(lfs)
    elif overallVar.get() == "61 - 70":
        for lofs in listForScores:
            if int(lofs[3]) >= 61 and int(lofs[3]) <= 70:
                scoreList.append(lofs)
    elif overallVar.get() == "71 - 80":
        for oneScore in listForScores:
            if int(oneScore[3]) >= 71 and int(oneScore[3]) <= 80:
                scoreList.append(oneScore)
    elif overallVar.get() == "81 - 90":
        for singScore in listForScores:
            if int(singScore[3]) >= 81 and int(singScore[3]) <= 90:
                scoreList.append(singScore)
    elif overallVar.get() == "99 - 100":
        for ind in listForScores:
            if int(ind[3]) >= 91 and int(ind[3]) <= 100:
                scoreList.append(ind)

    return scoreList

def filterResults():
   
    global allPlayers, listToUse, currentFilterList, finalList
    finalList = []

    listWith20FilteredOut = handleTop20()
    listWithPositionsFilteredOut = handlePositions(listWith20FilteredOut)
    listWithFootFilteredOut = handleFoot(listWithPositionsFilteredOut)
    listWithCountryFilteredOut = handleCountry(listWithFootFilteredOut)
    listWithClubFilteredOut = handleClubs(listWithCountryFilteredOut)
    listWithInitialFilteredOut = handleInitial(listWithClubFilteredOut)
    listWithOverallFilteredOut = handleOverall(listWithInitialFilteredOut)
    listWithAgeFilteredOut = handleAge(listWithOverallFilteredOut)
    litstWithWageFilteredOut = handleWage(listWithAgeFilteredOut)
    finalList = handleDuplicates(litstWithWageFilteredOut)

    updatePlayerListBox(finalList)

def updatePlayerListBox(playerList):

    playersListbox.delete(0, END)

    temp = []
    between = "Of"
    for player in playerList:
        temp.append(f'{player[0][:15]:<18} {between:<8} {player[4]:<20}')

    playersVar.set(temp)
       
def character_limit(entry_text):
    if len(entry_text.get()) > 0:
        entry_text.set(entry_text.get()[-1])

#MAIN
#Holding frames
#########
global allPlayers
global countriesList
global clubsList
allPlayers, inTop20List, countriesList, clubsList, overallList = getPlayer("fifa_wc.csv")
global finalList
finalList = allPlayers[:]  #set as the default

countriesList = list(dict.fromkeys(countriesList))
clubsList = list(dict.fromkeys(clubsList))

##overallNum = []
##for o in overallList:
##    overallNum.append(int(o))
##print(min(overallNum)) = 46
##print(max(overallNum)) = 94

root = Tk()
root.title("Jen Tat ~ Fifa World Cup Guide")
mainframe = Frame(root)
secframe = Frame(root)
triframe = Frame(root)

#Images
#########
fifaLogoImage = Image.open("fifaLogo.png").resize((268, 300))
fifaLogoPhoto = ImageTk.PhotoImage(fifaLogoImage)

#Widgets
#########
root.config(bg="white")
mainframe.config(bg="white")
secframe.config(bg="white")
triframe.config(bg="white")

cv = Canvas(secframe, bg="white", highlightcolor="white", highlightbackground="white", width=400, height=400)
cv.create_image(200, 150, image=fifaLogoPhoto)

titleLabel = Label(mainframe, text="Fifa World Cup Player Guide", bg="white", font=("Verdana", 24))

scrollbar = Scrollbar(mainframe)
playersVar = StringVar()
playersListbox = Listbox(mainframe, listvariable = playersVar, width=50, font=("Courier", 11), yscrollcommand=scrollbar.set)
playersListbox.bind("<Double-Button-1>", setCurrentSelection)
scrollbar.config(command=playersListbox.yview)

updatePlayerListBox(allPlayers)

currentSelectionPlayerVar = StringVar()
currentSelectionPlayerVar.set("Name Of Player: ")
currentSelectionPlayerLabel = Label(mainframe, bg="white", textvariable=currentSelectionPlayerVar, font=("Verdana", 12))

currentSelectionClubVar = StringVar()
currentSelectionClubVar.set("Club Name: ")
currentSelectionClubLabel = Label(mainframe, bg="white", textvariable=currentSelectionClubVar, font=("Verdana", 12))

findRandomPlayersButton = Button(mainframe, text="Reset", command=findRandomPlayers, bg="#1663BE", activebackground="#23395D", fg="white", activeforeground="white", font=("Verdana", 14))
alphabetizePlayersButton = Button(mainframe, text="Alphabetize", command=alphabetizePlayers, bg="#1663BE", activebackground="#23395D", fg="white", activeforeground="white", font=("Verdana", 14))

top20Frame = LabelFrame(mainframe, text="In The Top 20 Club List?", font=("Verdana", 13), bg="white")
top20Var = StringVar()
top20Var.set("All")
ytop20Radio = Radiobutton(top20Frame, text="Yes", variable=top20Var, value="Yes", bg="white", font=("Verdana", 12))
ntop20Radio = Radiobutton(top20Frame, text="No", variable=top20Var, value="No", bg="white", font=("Verdana", 12))
allRadio = Radiobutton(top20Frame, text="All", variable=top20Var, value="All", bg="white", font=("Verdana", 12))
##top20Button = Button(mainframe, text="Go!", command=sortByTop20)

positionFrame = LabelFrame(mainframe, text="Position:", font=("Verdana", 12), bg="white")
defenceCheckVar = IntVar()
defenceCheckVar.set(1)
defenceCheck = Checkbutton(positionFrame, text = "Defence", onvalue=1, offvalue = 0, variable = defenceCheckVar, command=defenceControl, bg="white", font=("Verdana", 11))
forwardCheckVar = IntVar()
forwardCheckVar.set(1)
forwardCheck = Checkbutton(positionFrame, text = "Forward", onvalue=1, offvalue = 0, variable = forwardCheckVar, command=forwardControl, bg="white", font=("Verdana", 11))
goalkeeperCheckVar = IntVar()
goalkeeperCheckVar.set(1)
goalkeeperCheck = Checkbutton(positionFrame, text = "Goal Keeper", onvalue=1, offvalue = 0, variable = goalkeeperCheckVar, command=filterResults, bg="white", font=("Verdana", 11))
midfieldCheckVar = IntVar()
midfieldCheckVar.set(1)
midfieldCheck = Checkbutton(positionFrame, text = "Mid Field", onvalue=1, offvalue = 0, variable = midfieldCheckVar, command=filterResults, bg="white", font=("Verdana", 11))

ageScaleVar = IntVar()
ageScale = Scale(secframe, bg="white", highlightcolor="white", highlightbackground="white", from_=10, to=50, tickinterval=20, variable=ageScaleVar, showvalue=True, label="Age", orient=HORIZONTAL, length=400, troughcolor="#B53737", font=("Verdana", 14))
ageScale.bind("<B1-Motion>", changeAge)

wageScaleVar = IntVar()
wageScale = Scale(secframe, bg="white", highlightcolor="white", highlightbackground="white", from_=1, to=585, variable=wageScaleVar, tickinterval=292, showvalue=True, label="Wage (K)", orient=VERTICAL, length=700, troughcolor="#EFCC90", font=("Verdana", 14))
wageScale.bind("<B1-Motion>", changeWage)
wageScale.bind("<Button-1>")

useAgeVar = IntVar()
useAgeVar.set(1)
useAgeScale = Scale(secframe, bg="white", highlightcolor="white", highlightbackground="white", variable=useAgeVar, width=50, length=100, from_=1, to=2, showvalue=False, label="Use Age?", orient=HORIZONTAL, command=useAgeControl, troughcolor="#B53737", font=("Verdana", 14))  
yinstructLabel = Label(secframe, bg="white", text="Y", font=("Verdana", 12))
ninstructLabel = Label(secframe, bg="white", text="N", font=("Verdana", 12))

footLabel = Label(mainframe, bg="white", text="Preferred Foot", font=("Verdana", 16))
footPreferences = ["Either", "Left", "Right"]
preferredFootVar = StringVar()
preferredFootSpinbox = Spinbox(mainframe, textvariable=preferredFootVar, values=footPreferences, font=("Verdana", 14))

countriesLabel = Label(mainframe, bg="white", text="Nationality", font=("Verdana", 16))
countriesList.sort()
countriesList.insert(0, "All")
countriesOptionVar = StringVar()
countriesOptionVar.set("All")
countriesOption = OptionMenu(mainframe, countriesOptionVar, *countriesList)
countriesOption.config(bg="#B53737", fg="white", activebackground="#800000", width=11, font=("Verdana", 14))
countriesOption["menu"].config(font=("Verdana",(14)),bg="white", activebackground="#800000")

useInitFrame = LabelFrame(mainframe, text="Use First Initial?", font=("Verdana", 13), bg="white")
useInitVar = StringVar()
useInitVar.set("No")
yInitRadio = Radiobutton(useInitFrame, text="Yes", variable=useInitVar, value="Yes", bg="white", font=("Verdana", 12))
nInitRadio = Radiobutton(useInitFrame, text="No", variable=useInitVar, value="No", bg="white", font=("Verdana", 12))

typeInitVar = StringVar()
typeInitVar.set("First Initial")
typeInitLabel = Label(mainframe, bg="white", textvariable=typeInitVar, font=("Verdana", 16))
firstInitVar = StringVar()
firstInitEntry = Entry(mainframe, textvariable=firstInitVar)
firstInitEntry.config(relief=GROOVE, font=("Verdana", 18), justify=CENTER, width=17)
firstInitVar.trace("w", lambda *args: character_limit(firstInitVar))

clubsLabel = Label(secframe, bg="white", text="Club", font=("Verdana", 16))
clubsList.sort()
clubsList.insert(0, "All")
clubsOptionVar = StringVar()
clubsOptionVar.set("All")
clubsOption = OptionMenu(secframe, clubsOptionVar, *clubsList)
clubsOption.config(bg="#1663BE", fg="white", activebackground="#23395D", activeforeground="white", width=11, font=("Verdana", 14))
clubsOption["menu"].config(font=("Verdana",(14)),bg="white", activebackground="#23395D")

overallLabel = Label(secframe, bg="white", text="Overall", font=("Verdana", 16))
overallScores = ["All", "40 - 50", "51 - 60", "61 - 70", "71 - 80", "81 - 90", "91 - 100"]
overallVar = StringVar()
overallSpinbox = Spinbox(secframe, textvariable=overallVar, values=overallScores, font=("Verdana", 14))

useWageVar = IntVar()
useWageVar.set(1)
useWageScale = Scale(secframe, bg="white", highlightcolor="white", highlightbackground="white", variable=useWageVar, width=50, length=100, from_=1, to=2, showvalue=False, label="Use Wage?", orient=HORIZONTAL, command=useWageControl, troughcolor="#EFCC90", font=("Verdana", 12))  
WyinstructLabel = Label(secframe, bg="white", text="Y", font=("Verdana", 12))
WninstructLabel = Label(secframe, bg="white", text="N", font=("Verdana", 12))

filterButton = Button(triframe, text="Filter Using All Selections", command=filterResults, bg="#EFCC90", activebackground="#E5AD4D", fg="white", activeforeground="white", font=("Verdana 18 bold",  18))
#GRID THE WIDGETS
###########
root.minsize(width=450, height=200)

mainframe.grid(row=1, column=1, padx = 50, pady = 50)

titleLabel.grid(row=1, column=1)
currentSelectionPlayerLabel.grid(row=2, column=1, sticky=W)
currentSelectionClubLabel.grid(row=3, column=1, sticky=W)
playersListbox.grid(row=4, column=1, columnspan=2, sticky=W)
scrollbar.grid(row=4, column=2, sticky=W)
findRandomPlayersButton.grid(row=5, column=1, ipadx=60, ipady=10, pady=(13, 0), sticky=W)
alphabetizePlayersButton.grid(row=5, column=1, ipadx=40, ipady=10, pady=(13, 0), sticky=E)

top20Frame.grid(row=6, column=1, ipady=20, pady=(20, 0), sticky=W)
ytop20Radio.grid(row=1, sticky=W)
ntop20Radio.grid(row=2, sticky=W)
allRadio.grid(row=3, sticky=W)
##top20Button.grid(row=6, column=1, ipadx=30, ipady=10)

positionFrame.grid(row=6, column=1, ipadx=30, ipady=5, pady=(20, 0), sticky=E)
defenceCheck.grid(row=1, sticky=W)
forwardCheck.grid(row=2, sticky=W)
goalkeeperCheck.grid(row=3, sticky=W)
midfieldCheck.grid(row=4, sticky=W)

footLabel.grid(row=7, column=1, sticky=W)
preferredFootSpinbox.grid(row=7, column=1, columnspan=1, sticky=E)
countriesLabel.grid(row=8, column=1, sticky=W)
countriesOption.grid(row=8, column=1, ipadx=44, sticky=E)
typeInitLabel.grid(row=9, column=1, sticky=W)
firstInitEntry.grid(row=9, column=1, ipady=10, sticky=E)
useInitFrame.grid(row=10, column=1, columnspan=2, ipadx=150, pady=(20, 0), sticky=W)
yInitRadio.grid(row=1, column=1, sticky=W)
nInitRadio.grid(row=1,column=2, sticky=E)

secframe.grid(row=1, column=2, sticky=E)
wageScale.grid(row=1, column=9, rowspan=800, sticky=NW, pady=50, padx=(0, 50))
cv.grid(row=1, column=2, columnspan=4, pady=50)
ageScale.grid(row=1, column=2, columnspan=4, sticky=SW, padx=(0, 50))
useAgeScale.grid(row=2, column=2, columnspan=2, sticky=NW, pady=(0, 20))
yinstructLabel.grid(row=2, column=2, sticky=SW, padx=(5, 0))
ninstructLabel.grid(row=2, column=2, sticky=SE)
clubsLabel.grid(row=3, column=2, sticky=W)
clubsOption.grid(row=3, column=3, ipadx=44)
overallLabel.grid(row=4, column=2, sticky=W)
overallSpinbox.grid(row=4, column=3, columnspan=1)
useWageScale.grid(row=5, column=2, columnspan=2, sticky=NW, pady=(0, 20))
WyinstructLabel.grid(row=5, column=2, sticky=SW, padx=(5, 0))
WninstructLabel.grid(row=5, column=2, sticky=SE)

triframe.grid(row=2, column=1, columnspan=2, padx=50)
filterButton.grid(row=1, column=1, columnspan=2, ipadx=100, ipady=20, pady=(0, 100))

root.mainloop()
